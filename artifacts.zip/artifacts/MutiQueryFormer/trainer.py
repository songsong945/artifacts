import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from utils.dataset_old import PlanTreeDataset
from utils.database_util import collator, get_job_table_sample
from utils.util import chunks
import os
import time
import torch
from scipy.stats import pearsonr
from tkinter import _flatten


def print_qerror(preds_unnorm, labels_unnorm, prints=True):
    qerror = []
    # print("print_qerror")
    # print(preds_unnorm)
    # print(labels_unnorm)
    for i in range(len(preds_unnorm)):
        if preds_unnorm[i] > float(labels_unnorm[i]):
            qerror.append(preds_unnorm[i] / float(labels_unnorm[i]))
        else:
            qerror.append(float(labels_unnorm[i]) / float(preds_unnorm[i]))

    e_50, e_90, e_95, e_99, e_max = np.median(qerror), np.percentile(qerror, 90), \
                                    np.percentile(qerror, 95), np.percentile(qerror, 99), np.max(qerror)
    e_mean = np.mean(qerror)

    if prints:
        print("Median: {}".format(e_50))
        print("90th percentile: {}".format(np.percentile(qerror, 90)))
        #    print("95th percentile: {}".format(np.percentile(qerror, 95)))
        #    print("99th percentile: {}".format(e_99))
        print("Max: {}".format(e_max))
        print("Mean: {}".format(e_mean))

    res = {
        'q_median': e_50,
        'q_90': e_90,
        'q_95': e_95,
        'q_99': e_99,
        'q_max': e_max,
        'q_mean': e_mean,
    }

    return res


def scatter_res(ps, ls, save_file=None):
    fig, ax = plt.subplots(figsize=(6, 6))
    plt.scatter(ls, ps, s=2)
    ax.plot([0, 1], [0, 1])  # , transform=ax.transAxes)
    plt.xlabel('gt')
    plt.ylabel('output')
    if save_file is not None:
        plt.savefig(save_file)


def eval_workload(workload, methods):
    get_table_sample = methods['get_sample']

    workload_file_name = './data/imdb/workloads/' + workload
    table_sample = get_table_sample(workload_file_name)
    plan_df = pd.read_csv('./data/imdb/{}_plan.csv'.format(workload))
    workload_csv = pd.read_csv('./data/imdb/workloads/{}.csv'.format(workload), sep='#', header=None)
    workload_csv.columns = ['table', 'join', 'predicate', 'cardinality']
    ds = PlanTreeDataset(plan_df, workload_csv, \
                         methods['encoding'], methods['hist_file'], methods['card_norm'], \
                         methods['cost_norm'], methods['to_predict'], table_sample)
    if methods['to_predict'] == 'cost':
        norm = methods['cost_norm']
    elif methods['to_predict'] == 'card':
        norm = methods['card_norm']
    else:
        raise Exception('unknown pred type')

    eval_score, eval_ps, eval_ls = evaluate(methods['model'], ds, methods['bs'], norm, methods['to_predict'],
                                            methods['device'])
    return eval_score, ds


def get_abs_errors(ps, ls):  # unnormalised
    ps = np.array(ps)
    ls = np.array(ls)
    abs_diff = np.abs(ps - ls)

    corr, _ = pearsonr(ps, ls)
    log_corr, _ = pearsonr(np.log(ps), np.log(ls))
    res = {
        'rmse': (abs_diff ** 2).mean() ** 0.5,
        'corr': corr,
        'log_corr': log_corr,
        'abs_median': np.median(abs_diff),
        'abs_90': np.percentile(abs_diff, 90),
        'abs_95': np.percentile(abs_diff, 95),
        'abs_99': np.percentile(abs_diff, 99),
        'abs_max': np.max(abs_diff)
    }

    # print("abs err: ", (e_50, e_90, e_95, e_99, e_max))
    return res


def evaluate(model, ds, bs, norm, device, prints=True):
    model.eval()
    cost_predss = np.empty(0)

    with torch.no_grad():
        for i in range(0, len(ds), bs):
            batch, batch_labels, query_len = collator(list(zip(*[ds[j] for j in range(i, min(i + bs, len(ds)))])))

            batch = batch.to(device)

            cost_preds = model(batch, query_len)
            cost_preds = cost_preds.squeeze()

            cost_predss = np.append(cost_predss, cost_preds.cpu().detach().numpy())

    # print(norm.unnormalize_labels(cost_predss))
    # print(list(_flatten(ds.costs)))
    scores = print_qerror(norm.unnormalize_labels(cost_predss), list(_flatten(ds.costs)), prints)
    abs_errors = get_abs_errors(norm.unnormalize_labels(cost_predss), list(_flatten(ds.costs)))
    return (scores, abs_errors), cost_predss, ds.costs


def train(model, train_ds, val_ds, crit, cost_norm, args, optimizer=None, scheduler=None):
    bs, device, epochs, clip_size = args.bs, args.device, args.epochs, args.clip_size
    lr = args.lr

    if not optimizer:
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    if not scheduler:
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 20, 0.7)

    t0 = time.time()

    rng = np.random.default_rng()

    best_prev = 999999

    for epoch in range(epochs):
        losses = 0
        cost_predss = np.empty(0)
        best_model_path = None

        model.train()

        train_idxs = rng.permutation(len(train_ds))

        cost_labelss = np.array(train_ds.costs)[train_idxs]
        # print("cost_labelss")
        # print(cost_labelss)

        for idxs in chunks(train_idxs, bs):
            optimizer.zero_grad()

            batch, batch_labels, query_len = collator(list(zip(*[train_ds[j] for j in idxs])))

            # batch_labels = list(batch_labels)
            # print(batch_labels)

            batch_labels = [list(cost_norm.normalize_labels(label)) for label in batch_labels]

            # print(batch_labels)

            batch_cost_label = torch.FloatTensor(batch_labels).to(device)
            batch = batch.to(device)

            # query_len = torch.IntTensor(query_len).to(device)

            model = model.to(device)

            cost_preds = model(batch, query_len)
            cost_preds = cost_preds.squeeze()

            # print(batch_cost_label)
            # print(cost_preds)

            loss = crit(cost_preds, batch_cost_label)
            loss.backward()

            # torch.nn.utils.clip_grad_norm_(model.parameters(), clip_size)

            optimizer.step()
            losses += loss.item()
            cost_predss = np.append(cost_predss, cost_preds.detach().cpu().numpy())

        test_scores, test_preds, test_labels = evaluate(model, val_ds, bs, cost_norm, device, False)

        qscores, absscores = test_scores
        if test_scores[0]['q_mean'] < best_prev:  ## mean mse
            best_model_path = logging(args, epoch, qscores, absscores, filename='log.txt', save_model=True, model=model)
            best_prev = test_scores[0]['q_mean']

        if epoch % 1 == 0:
            print('Epoch: {}  Avg Loss: {}, Time: {}'.format(epoch, losses / len(train_ds), time.time() - t0))
            print_qerror(cost_norm.unnormalize_labels(cost_predss), list(cost_labelss.flatten()))

            print('Eval:')
            test_scores, test_preds, test_labels = evaluate(model, val_ds, bs, cost_norm, device, False)
            print_qerror(cost_norm.unnormalize_labels(test_preds), list(_flatten(test_labels)))

        scheduler.step()

    return model, best_model_path


def logging(args, epoch, qscores, absscores, filename=None, save_model=False, model=None):
    arg_keys = [attr for attr in dir(args) if not attr.startswith('__')]
    arg_vals = [getattr(args, attr) for attr in arg_keys]

    res = dict(zip(arg_keys, arg_vals))
    model_checkpoint = str(args.example_num) + '_' + str(args.epochs) + '.pt'

    res['epoch'] = epoch
    res['model'] = model_checkpoint

    res = {**res, **qscores, **absscores}

    filename = args.newpath + filename
    model_checkpoint = args.newpath + model_checkpoint

    print(model_checkpoint)

    if filename is not None:
        if os.path.isfile(filename):
            df = pd.read_csv(filename)
            df = df.append(res, ignore_index=True)
            df.to_csv(filename, index=False)
        else:
            df = pd.DataFrame(res, index=[0])
            df.to_csv(filename, index=False)
    if save_model:
        torch.save({
            'model': model.state_dict(),
            'args': args
        }, model_checkpoint)

    return res['model']
