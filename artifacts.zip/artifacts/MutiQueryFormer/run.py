import os
import time

import torch
import numpy as np

from models.model import MutiQueryFormer
from planner import loadquery
from planner.optimizer import Optimizer
from utils import postgres, plans_lib, graphs
from utils.parameter import Args


def ExecuteSql(sql_str,
               hint_str,
               curr_timeout_ms=None,
               use_local_execution=True,
               engine='postgres'):

    if engine == 'postgres':
        return postgres.ExplainAnalyzeSql(sql_str,
                                          comment=hint_str,
                                          verbose=False,
                                          geqo_off=True,
                                          timeout_ms=curr_timeout_ms,
                                          remote=not use_local_execution)


def ParseExecutionResult(result_tup):
    result = result_tup.result
    # has_timeout = result_tup.has_timeout
    server_ip = result_tup.server_ip
    json_dict = result[0][0][0]
    real_cost = json_dict['Execution Time']

    return result_tup, real_cost, server_ip


class Planner(object):

    def __init__(self):
        self.args = Args()
        self.workload = self._MakeWorkload()
        self.nodes = self.workload.Queries(split='all')
        self.model = self._MakeModel()
        self.optimizer = self._MakeOptimizer()

    def _MakeModel(self):
        dev = 'cuda' if torch.cuda.is_available() else 'cpu'
        model = MutiQueryFormer()
        return model.to(dev)

    def _MakeWorkload(self):
        wp = loadquery.JoinOrderBenchmark.Params()
        workload = wp.cls(wp)
        return workload

    def _MakeWorkloadInfo(self):
        workload_info = plans_lib.WorkloadInfo(self.nodes)
        workload_info.WithJoinGraph(graphs.JOIN_ORDER_BENCHMARK_JOIN_GRAPH)
        return workload_info

    def _MakeOptimizer(self):
        wi = self._MakeWorkloadInfo()
        featurizer = plans_lib.PreOrderSequenceFeaturizer(wi)
        query_featurizer = plans_lib.QueryFeaturizer(wi)

        return Optimizer(wi, featurizer, query_featurizer, self.model)

    def SelectPlan(self, found_plans, predicted_latency, found_plan, planner,
                   query_node):
        rand_idx = np.random.randint(len(found_plans))
        predicted_latency, found_plan = found_plans[rand_idx]

        return predicted_latency, found_plan

    def run(self):
        planner = self._MakeOptimizer()
        model = self.model
        model.eval()
        nodes = self.nodes

        # self.timer.Start('plan_test_set' if is_test else 'plan')
        for i, node in enumerate(nodes):

            torch.cuda.empty_cache()
            found_plan = planner.plan(
                node,
                self.args.search_method,
            )

            hint_str = found_plan.hint_str(with_physical_hints=True)
            start = time.perf_counter()
            result_tup = ExecuteSql(node.info['sql_str'], hint_str)
            end = time.perf_counter()
            print('running time: %s ms' % ((end - start) * 1000))
            result, real_cost, _ = ParseExecutionResult(result_tup)

            print('q{}, real cost: {:.1f}'.format(node.info['query_name'], real_cost))


if __name__ == '__main__':
    planner = Planner()
    planner.run()
