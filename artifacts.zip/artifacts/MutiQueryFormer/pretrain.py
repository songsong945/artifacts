from models.model import MutiQueryFormer
from trainer import train
import torch.nn as nn

from utils.dataset import TrainSet
from utils.parameter import Args
from utils.util import Normalizer

args = Args()

max_train_num = 10000
max_evl_num = 2000

train_num = args.example_num*4/5
evl_num = args.example_num/5

train_ds = TrainSet('{}/workload_plan_train_data_{}_{}.csv'.format("./data", "002", "01"), train_num)
val_ds = TrainSet('{}/workload_plan_evl_data_{}_{}.csv'.format("./data", "002", "01"), evl_num)

print("load data success")

args = Args()
model = MutiQueryFormer()

cost_norm = Normalizer(0, 13)

loss = nn.MSELoss()

train(model, train_ds, val_ds, loss, cost_norm, args)
