import torch

tables = {'aka_name': 0, 'aka_title': 1, 'cast_info': 2, 'char_name': 3, 'comp_cast_type': 4,
          'company_name': 5, 'company_type': 6, 'complete_cast': 7, 'info_type': 8, 'keyword': 9,
          'kind_type': 10, 'link_type': 11, 'movie_companies': 12, 'movie_info': 13,
          'movie_info_idx': 14, 'movie_keyword': 15, 'movie_link': 16, 'name': 17, 'person_info': 18,
          'role_type': 19, 'title': 20}


class Args:

    def __init__(self):
        self.bs = 1
        self.device = torch.device('cuda:0')
        self.epochs = 100
        self.clip_size = 10
        self.lr = 0.001
        self.newpath = './data/'
        self.search_method = 'cache_set_priority_search'
        self.concurrent_number = 16
        self.lbda = 0.5
        self.budget = 200
        self.example_num = 10000
