from utils import postgres


class CardEst(object):
    def __call__(self, node, join_conds):
        raise NotImplementedError()


class PostgresCardEst(CardEst):

    def __init__(self):
        self._cache = {}

    def _HashKey(self, node):

        sorted_filters = '\n'.join(sorted(node.GetFilters()))
        sorted_leaves = '\n'.join(sorted(node.leaf_ids()))
        return sorted_leaves + sorted_filters

    def __call__(self, node, join_conds):
        key = self._HashKey(node)
        card = self._cache.get(key)
        if card is None:
            sql_str = node.to_sql(join_conds)
            card = postgres.GetCardinalityEstimateFromPg(sql=sql_str)
            self._cache[key] = card
        return card
