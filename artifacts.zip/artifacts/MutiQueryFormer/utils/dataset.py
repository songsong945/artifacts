import csv
from collections import deque

import torch
from torch.utils.data import Dataset
from utils.feature_extractor_old import traversePlan
from utils.parameter import tables
import numpy as np
import pandas as pd
import json


class NodeOneHot:

    def __init__(self, dictionary):
        self.level = 0  # root

        self.table = [0] * 21

        self.hash_join = 0
        self.nest_loop = 0
        self.merge_join = 0
        self.index_scan = 0
        self.seq_scan = 0
        self.aggregate = 0
        self.share = 0

        self.node_one_hot = [0] * 28

        self.children = []

        self.__dict__.update(dictionary)
        self.getNode()

    def update(self, dictionary):
        self.__dict__.update(dictionary)

    def getNode(self):
        self.node_one_hot[0] = self.hash_join
        self.node_one_hot[1] = self.nest_loop
        self.node_one_hot[2] = self.merge_join
        self.node_one_hot[3] = self.index_scan
        self.node_one_hot[4] = self.seq_scan
        self.node_one_hot[5] = self.aggregate
        self.node_one_hot[6] = self.share
        for i in range(21):
            self.node_one_hot[i + 7] = self.table[i]

    def __str__(self):
        #        return TreeNode.print_nested(self)
        return '{}'.format(self.node_one_hot)

    def __repr__(self):
        return self.__str__()

    def print_nested(self):
        print('--' * self.level + self.__str__())
        for k in self.children:
            k.print_nested()


def topo_sort(root_node):
    adj_list = []  # from parent to children
    num_child = []
    features = []

    toVisit = deque()
    toVisit.append((0, root_node))
    next_id = 1
    while toVisit:
        idx, node = toVisit.popleft()
        features.append(node.node_one_hot)
        num_child.append(len(node.children))
        for child in node.children:
            toVisit.append((next_id, child))
            adj_list.append((idx, next_id))
            next_id += 1

    return adj_list, num_child, features


def calculate_height(adj_list, tree_size):
    if tree_size == 1:
        return np.array([0])

    adj_list = np.array(adj_list)
    node_ids = np.arange(tree_size, dtype=int)
    node_order = np.zeros(tree_size, dtype=int)
    uneval_nodes = np.ones(tree_size, dtype=bool)

    parent_nodes = adj_list[:, 0]
    child_nodes = adj_list[:, 1]

    n = 0
    while uneval_nodes.any():
        uneval_mask = uneval_nodes[child_nodes]
        unready_parents = parent_nodes[uneval_mask]

        node2eval = uneval_nodes & ~np.isin(node_ids, unready_parents)
        node_order[node2eval] = n
        uneval_nodes[node2eval] = False
        n += 1
    return node_order


def pre_collate(position, treePlanOneHot):
    adj_list, num_child, features = topo_sort(treePlanOneHot)
    heights = calculate_height(adj_list, len(features))
    # print(len(features))
    positions = [position] * len(heights)

    print(len(features))
    print(len(heights))
    print(len(positions))

    return {'features': torch.FloatTensor(features),
            'positions': torch.IntTensor(positions),
            'heights': torch.IntTensor(heights)}


def list_add(a, b):
    c = []
    for i in range(len(a)):
        if a[i] == 0 and b[i] == 0:
            c.append(0)
        else:
            c.append(1)
    return c


def getNodeOneHot(treeNode):
    node = {'level': treeNode.level,
            'hash_join': 0,
            'nest_loop': 0,
            'merge_join': 0,
            'index_scan': 0,
            'seq_scan': 0,
            'share': 0,
            'aggregate': 0,
            'children': [],
            'table': [0] * 21}

    if treeNode.table is not None:
        node['table'][tables[treeNode.table]] = 1

    if treeNode.nodeType == 'Hash Join':
        node['hash_join'] = 1
    elif treeNode.nodeType == 'Nested Loop':
        node['nest_loop'] = 1
    elif treeNode.nodeType == 'Merge Join':
        node['merge_join'] = 1
    elif treeNode.nodeType == 'Index Scan' or treeNode.nodeType == 'Index Only Scan':
        node['index_scan'] = 1
    elif treeNode.nodeType == 'Seq Scan':
        node['seq_scan'] = 1
    elif treeNode.nodeType == 'Aggregate':
        node['aggregate'] = 1
    elif treeNode.nodeType == 'Share':
        node['share'] = 1

    for k in treeNode.children:
        children = getNodeOneHot(k)
        node['children'].append(children)
        node['table'] = list_add(node['table'], children.table)

    root_node = NodeOneHot(node)

    return root_node


def getNodeOneHotRuningTime(treeNode, level):
    
    node = {'level': treeNode.level,
            'hash_join': 0,
            'nest_loop': 0,
            'merge_join': 0,
            'index_scan': 0,
            'seq_scan': 0,
            'share_scan': 0,
            'aggregate': 0,
            'children': [],
            'table': [0] * 21}

    if treeNode.table is not None:
        node['table'][tables[treeNode.table]] = 1

    if treeNode.nodeType == 'Hash Join':
        node['hash_join'] = 1
    elif treeNode.nodeType == 'Nested Loop':
        node['nest_loop'] = 1
    elif treeNode.nodeType == 'Merge Join':
        node['merge_join'] = 1
    elif treeNode.nodeType == 'Index Scan' or treeNode.nodeType == 'Index Only Scan':
        node['index_scan'] = 1
    elif treeNode.nodeType == 'Seq Scan':
        node['seq_scan'] = 1
    elif treeNode.nodeType == 'Aggregate':
        node['aggregate'] = 1
    elif treeNode.nodeType == 'Share':
        node['share'] = 1

    for k in treeNode.children:
        children = getNodeOneHotRuningTime(k, level + 1)
        node['children'].append(children)
        node['table'] = list_add(node['table'], children.table)

    root_node = NodeOneHot(node)

    return root_node


class RunTimeSet(Dataset):
    def __init__(self, features, positions, heights):
        self.features = features
        self.positions = positions
        self.heights = heights

    def __getitem__(self, item):
        return {'features': self.features[item],
                'positions': self.positions[item],
                'heights': self.heights[item]}, 0

    def __len__(self):
        return len(self.heights)


class TrainSet(Dataset):
    def __init__(self, file_path, row_num=100):
        # print(file_path)
        self.planSet, self.costs = self.loader(file_path, row_num)
        self.length = len(self.planSet)
        self.features, self.positions, self.heights = self.collect()

    def __getitem__(self, item):
        return {'features': self.features[item],
                'positions': self.positions[item],
                'heights': self.heights[item]}, self.costs[item]

    def __len__(self):
        return self.length

    def loader(self, file_path, row_num):
        planSet = []
        costs = []
        plans = pd.read_csv(file_path, nrows=row_num)
        for plan in plans.workload:
            # print(plan)
            json_list = str(plan).split('#')
            # print(len(json_list))
            workload_json = json_list[::2]
            cost = json_list[1::2]
            cost = [int(x) for x in cost]
            planSet.append(workload_json)
            costs.append(cost)
        return planSet, costs

    def collect(self):
        features = []
        positions = []
        heights = []
        for plans in self.planSet:
            planDict = self.js_node2dict(plans)
            features.append(planDict['features'])
            positions.append(planDict['positions'])
            heights.append(planDict['heights'])

        return features, positions, heights

    def js_node2dict(self, plans):
        lens = len(plans)
        features = []
        positions = []
        heights = []
        for i in range(lens):
            treePlan = traversePlan(json.loads(plans[i]))
            #print(treePlan)
            treePlanOneHot = getNodeOneHot(treePlan)
            collated_dict = pre_collate(i, treePlanOneHot)
            # print(len(collated_dict['features']))
            features.append(collated_dict['features'])
            positions.append(collated_dict['positions'])
            heights.append(collated_dict['heights'])

        return {'features': features,
                'positions': positions,
                'heights': heights}
