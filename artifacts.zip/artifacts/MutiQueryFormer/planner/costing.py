from utils import card_est
from utils import hyperparams
from utils import postgres


class CostModel(object):
    @classmethod
    def Params(cls):
        p = hyperparams.InstantiableParams(cls)
        p.Define('cost_physical_ops', False,
                 'Costs physical ops or just join orders?')
        return p

    def __init__(self, params):
        self.params = params.Copy()

    def __call__(self, node, join_conds):

        raise NotImplementedError('Abstract method')

    def ScoreWithSql(self, node, sql):
        raise NotImplementedError('Abstract method')


class NullCost(CostModel):
    """Sets the cost of any plan to 0."""

    def __call__(self, node, join_conds):
        return 0

    def ScoreWithSql(self, node, sql):
        return 0


class PostgresCost(CostModel):
    """The Postgres cost model."""

    def __call__(self, node, join_conds):
        sql_str = node.to_sql(join_conds, with_select_exprs=True)
        return self.ScoreWithSql(node, sql_str)

    def ScoreWithSql(self, node, sql):
        p = self.params
        cost = postgres.GetCostFromPg(
            sql=sql,
            hint=node.hint_str(with_physical_hints=p.cost_physical_ops),
            check_hint_used=True,
        )
        return cost


class MinCardCost(CostModel):

    def __init__(self, params):
        super().__init__(params)
        self.card_est = card_est.PostgresCardEst()

    def __call__(self, node, join_conds):
        return self.Score(node, join_conds)

    def GetModelCardinality(self, node, join_conds):
        joins = node.KeepRelevantJoins(join_conds)
        if len(joins) == 0 and len(node.GetFilters()) == 0:
            return self.GetBaseRelCardinality(node)
        return self.card_est(node, joins)

    def GetBaseRelCardinality(self, node):
        assert node.table_name is not None, node
        return postgres.GetAllTableNumRows([node.table_name])[node.table_name]

    def Score(self, node, join_conds):
        if node._card:
            return node._card

        card = self.GetModelCardinality(node, join_conds)
        if node.IsScan():
            node._card = card
        else:
            assert node.IsJoin(), node
            c_t1 = self.Score(node.children[0], join_conds)
            c_t2 = self.Score(node.children[1], join_conds)
            node._card = card + c_t1 + c_t2

        return node._card
