import collections
import copy
import time

import numpy as np
import torch

from planner import search
from utils import plans_lib
from utils.database_util import collator
from utils.dataset import getNodeOneHotRuningTime, pre_collate, RunTimeSet
from utils.parameter import Args
from utils.plans_lib import check

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'


class PlannerConfig(
    collections.namedtuple(
        'PlannerConfig',
        [
            'search_space', 'enable_nestloop', 'enable_hashjoin',
            'enable_mergejoin'
        ],
    )):
    @classmethod
    def Get(cls, name):
        return {
            'NestLoopHashJoin': PlannerConfig.NestLoopHashJoin(),
            'LeftDeepNestLoop': PlannerConfig.LeftDeepNestLoop(),
            'LeftDeepNestLoopHashJoin':
                PlannerConfig.LeftDeepNestLoopHashJoin(),
            'LeftDeep': PlannerConfig.LeftDeep(),
            'Dbmsx': PlannerConfig.Dbmsx(),
        }[name]

    @classmethod
    def Default(cls):
        return cls(search_space='bushy',
                   enable_nestloop=True,
                   enable_hashjoin=True,
                   enable_mergejoin=True)

    @classmethod
    def NestLoopHashJoin(cls):
        return cls(search_space='bushy',
                   enable_nestloop=True,
                   enable_hashjoin=True,
                   enable_mergejoin=False)

    @classmethod
    def LeftDeepNestLoop(cls):
        return cls(search_space='leftdeep',
                   enable_nestloop=True,
                   enable_hashjoin=False,
                   enable_mergejoin=False)

    @classmethod
    def LeftDeepNestLoopHashJoin(cls):
        return cls(search_space='leftdeep',
                   enable_nestloop=True,
                   enable_hashjoin=True,
                   enable_mergejoin=False)

    @classmethod
    def LeftDeep(cls):
        return cls(search_space='leftdeep',
                   enable_nestloop=True,
                   enable_hashjoin=True,
                   enable_mergejoin=True)

    @classmethod
    def Dbmsx(cls):
        return cls(search_space='dbmsx',
                   enable_nestloop=True,
                   enable_hashjoin=True,
                   enable_mergejoin=True)

    def KeepEnabledJoinOps(self, join_ops):
        ops = []
        for op in join_ops:
            if op == 'Nested Loop' and self.enable_nestloop:
                ops.append(op)
            elif op == 'Hash Join' and self.enable_hashjoin:
                ops.append(op)
            elif op == 'Merge Join' and self.enable_mergejoin:
                ops.append(op)
        assert len(ops) > 0, (self, join_ops)
        return ops


class Optimizer(object):
    """Creates query execution plans using learned model."""

    def __init__(
            self,
            workload_info,
            plan_featurizer,
            # parent_pos_featurizer,
            query_featurizer,
            # inverse_label_transform_fn,
            model,
            beam_size=10,
            search_until_n_complete_plans=1,
            plan_physical=False,
            use_label_cache=True,
            use_plan_restrictions=True,
    ):
        self.args = Args()
        self.workload_info = workload_info
        self.plan_featurizer = plan_featurizer
        # self.parent_pos_featurizer = parent_pos_featurizer
        self.query_featurizer = query_featurizer
        # self.inverse_label_transform_fn = inverse_label_transform_fn
        self.use_label_cache = use_label_cache
        self.use_plan_restrictions = use_plan_restrictions

        # Plan search params
        # if not plan_physical:
        #     jts = workload_info.join_types
        #     print(jts)
        #     #assert np.array_equal(jts, ['Join']), jts
        #     sts = workload_info.scan_types
        #     assert np.array_equal(sts, ['Scan']), sts
        self.plan_physical = plan_physical
        self.beam_size = beam_size
        self.search_until_n_complete_plans = search_until_n_complete_plans
        self.model = model
        self.con_current_query = {'features': [], 'positions': [], 'heights': []}
        self.cached_nodes = []

        # Debugging.
        self.total_joins = 0
        self.total_random_triggers = 0
        self.num_queries_with_random = 0

    def SetModel(self):
        self.value_network = self.model.to(DEVICE)
        # Set the model in eval mode.  Only affects modules (e.g., Dropout)
        # that have different behaviors in train vs. in test.  Do it once here
        # so that Optimizer.plan() below doesn't have to do it on every query.
        self.value_network.eval()

    def update_con_current_query(self, plan):
        if len(self.con_current_query) == self.args.concurrent_number - 1:
            del (self.con_current_query['features'][0])
            del (self.con_current_query['positions'][self.args.concurrent_number - 1])
            del (self.con_current_query['heights'][0])

        self.con_current_query = self.real_plan_featurizer(plan)

    def select_cache_node(self, plan):
        cached_node = []
        cur_time = time.time()
        for node in self.cached_nodes:
            cached_node.append((node.get_weigh_value(cur_time, self.args.lbda), node))
        queue = [plan]
        while len(queue) > 0:
            head = queue[0]
            del (queue[0])
            head.access_list.append(cur_time)
            cached_node.append((head.get_weigh_value(cur_time, self.args.lbda), head))
            for node in head.children:
                queue.append(node)
        sorted(cached_node, key=(lambda x: x[0]), reverse=True)
        self.cached_nodes = []
        for i in range(self.args.budget):
            node = cached_node[i][1]
            node.is_share = True
            self.cached_nodes.append(copy.deepcopy(node))

    def real_plan_featurizer(self, plan):
        features = self.con_current_query['features']
        positions = self.con_current_query['positions']
        heights = self.con_current_query['heights']

        position = len(positions)

        treePlanOneHot = getNodeOneHotRuningTime(plan, 0)
        collated_dict = pre_collate(position, treePlanOneHot)

        features.append(collated_dict['features'])
        positions.append(collated_dict['positions'])
        heights.append(collated_dict['heights'])

        return {'features': features,
                'positions': positions,
                'heights': heights}

    def plan_node_featurizer(self, possible_plans):
        features = []
        positions = []
        heights = []
        for plan in possible_plans:
            plan_enc = self.real_plan_featurizer(plan)
            features.append(plan_enc['features'])
            positions.append(plan_enc['positions'])
            heights.append(plan_enc['heights'])
        return RunTimeSet(features, positions, heights)

    # @profile
    def infer(self, possible_plans, set_model_eval=False):

        labels = [None] * len(possible_plans)

        plan_nodes = self.plan_node_featurizer(possible_plans)

        # Perform inference on new plans.
        if set_model_eval:
            # Expensive.  Caller should try to call only once.
            self.value_network.eval()

        with torch.no_grad():
            for i in range(0, len(plan_nodes)):
                batch, batch_labels, query_len = collator(list(zip(*[plan_nodes[i]])))

                batch = batch.to(torch.device('cuda:0'))

                cost_preds = self.value_network(batch, query_len)
                cost_preds = cost_preds.squeeze()
                cost_preds = cost_preds.cpu().detach().numpy()

                # print(cost_preds)
                labels[i] = sum(cost_preds)

        return labels

    def plan(self, query_node, search_method, **kwargs):
        torch.cuda.empty_cache()
        self.SetModel()
        if search_method == 'plan_priority_search':
            plan = self._plan_priority_search(query_node)
        elif search_method == 'cache_set_priority_search':
            plan = self._cache_set_priority_search(query_node)
        else:
            raise ValueError(f'Unsupported search_method: {search_method}')
        print(plan)
        self.update_con_current_query(plan)
        self.select_cache_node(plan)
        return plan

    def _get_possible_plans(self,
                            query_node,
                            state,
                            join_graph,
                            bushy=True,
                            planner_config=None,
                            avoid_eq_filters=False):
        """Expands a state.  Returns a list of successor states."""
        if not bushy:
            if planner_config.search_space == 'leftdeep':
                func = self._get_possible_plans_left_deep
            else:
                func = self._get_possible_plans_dbmsx
        else:
            func = self._get_possible_plans_bushy
        return func(query_node,
                    state,
                    join_graph,
                    planner_config=planner_config,
                    avoid_eq_filters=avoid_eq_filters)

    # @profile
    def _get_possible_plans_bushy(self,
                                  query_node,
                                  state,
                                  join_graph,
                                  planner_config=None,
                                  avoid_eq_filters=False):
        possible_joins = []
        num_rels = len(state)
        print('num_rels: {}'.format(num_rels))
        for i in range(num_rels):
            for j in range(num_rels):
                if i == j:
                    continue
                l = state[i]
                r = state[j]
                # Hinting a join between non-neighbors may fail (PG may
                # disregard the hint).
                if not plans_lib.ExistsJoinEdgeInGraph(l, r, join_graph):
                    continue
                for plan in self._enumerate_plan_operators(
                        l,
                        r,
                        planner_config=planner_config,
                        avoid_eq_filters=avoid_eq_filters):
                    possible_joins.append((plan, i, j))
        return possible_joins

    def _get_possible_plans_dbmsx(self,
                                  query_node,
                                  state,
                                  join_graph,
                                  planner_config=None,
                                  avoid_eq_filters=False):
        raise NotImplementedError

    def _get_possible_plans_left_deep(self,
                                      query_node,
                                      state,
                                      join_graph,
                                      planner_config=None,
                                      avoid_eq_filters=False):
        possible_joins = []
        num_rels = len(state)
        join_index = None
        for i, s in enumerate(state):
            if s.IsJoin():
                assert join_index is None, 'two joins found'
                join_index = i
        if join_index is None:
            # Base state: all unspecified scans.
            scored = set()
            for i in range(num_rels):
                for j in range(num_rels):
                    if i == j:
                        continue
                    if (i, j) in scored:
                        continue
                    scored.add((i, j))
                    l = state[i]
                    r = state[j]
                    # Hinting a join between non-neighbors may fail (PG may
                    # disregard the hint).
                    if not plans_lib.ExistsJoinEdgeInGraph(l, r, join_graph):
                        continue
                    for plan in self._enumerate_plan_operators(
                            l,
                            r,
                            planner_config=planner_config,
                            avoid_eq_filters=avoid_eq_filters):
                        possible_joins.append((plan, i, j))
        else:
            i, l = join_index, state[join_index]
            for j in range(0, len(state)):
                if j == i:
                    continue
                r = state[j]
                # Hinting a join between non-neighbors may fail (PG may
                # disregard the hint).
                if not plans_lib.ExistsJoinEdgeInGraph(l, r, join_graph):
                    continue
                for plan in self._enumerate_plan_operators(
                        l,
                        r,
                        planner_config=planner_config,
                        avoid_eq_filters=avoid_eq_filters):
                    possible_joins.append((plan, i, j))
        return possible_joins

    def _enumerate_plan_operators(self,
                                  left,
                                  right,
                                  planner_config=None,
                                  avoid_eq_filters=False):
        join_ops = self.workload_info.join_types
        scan_ops = self.workload_info.scan_types
        if planner_config:
            join_ops = planner_config.KeepEnabledJoinOps(join_ops)
        # Hack.
        if planner_config and planner_config.search_space == 'dbmsx':
            engine = 'dbmsx'
        else:
            engine = 'postgres'
        return search.EnumerateJoinWithOps(
            left,
            right,
            join_ops=join_ops,
            scan_ops=scan_ops,
            avoid_eq_filters=avoid_eq_filters,
            engine=engine,
            use_plan_restrictions=self.use_plan_restrictions)

    # @profile
    def _make_new_states(self, state, costs, possible_joins):
        num_rels = len(state)
        valid_costs = [None] * len(possible_joins)
        valid_new_states = [None] * len(possible_joins)
        for i in range(len(possible_joins)):
            join, left_idx, right_idx = possible_joins[i]
            join.cost = costs[i]
            new_state = state[:]  # Shallow copy.
            new_state[left_idx] = join
            del new_state[right_idx]
            new_state_cost = -1e30
            for rel in new_state:
                if rel.IsJoin():
                    # Goodness(state) = max V_theta(subplan), for all subplan
                    # in state.
                    new_state_cost = max(new_state_cost, rel.cost)
            valid_costs[i] = new_state_cost
            valid_new_states[i] = new_state
        return valid_costs, valid_new_states

    def _get_cost(self, node):
        return 0

    def _cache_set_filter(self, tables, filters):
        candidate_cache_set = []
        candidate_nodes = self.cached_nodes
        for candidate in candidate_nodes:
            can_tables = candidate.GetTables()
            can_filters = candidate.GetFilters()
            if check(can_tables, can_filters, tables, filters):
                cost = self._get_cost(candidate)
                candidate_cache_set.append((float(cost) / float(len(tables)), candidate, set(can_tables)))
        return candidate_cache_set

    def _search_cache_set(self, query_node):
        cache_set = []
        tables = []
        filters = []
        node_dict = {}
        for node in query_node:
            table = node.GetTables()
            assert len(table) == 1
            node_dict[table[0]] = node
            tables.extend(table)
            filters.extend(node.GetFilters())
        candidate_cache_set = self._cache_set_filter(tables, filters)
        candidate_cache_set = sorted(candidate_cache_set)

        tables = set(tables)
        for i in range(len(candidate_cache_set)):
            if len(tables) == 0:
                break
            candidate_node_tuple = candidate_cache_set[i]
            if candidate_node_tuple[2] <= tables:
                tables = tables - candidate_node_tuple[2]
                for t in candidate_node_tuple[2]:
                    del node_dict[t]
                cache_set.append(candidate_node_tuple[1])

        for node in node_dict.values():
            cache_set.append(node)
        return cache_set

    def _map_matching(self, plan):
        return plan

    # @profile
    def _model_based_plan_search(self,
                                 query_node,
                                 state,
                                 beam_size=2,
                                 bushy=True,
                                 planner_config=None,
                                 avoid_eq_filters=False):
        """Produce a plan via heuristic search.

        Args:
          query_node: a Node, a parsed version of the query to optimize.  In
            principle we should take the raw SQL string, but this is a
            convenient proxy.
        """
        planning_start_t = time.time()
        # Join graph.
        join_graph, _ = query_node.GetOrParseSql()

        # A fringe is a priority queue of (cost of a state, a state).
        # init the cost of first state as 0
        fringe = [(0, state)]

        terminal_states = []

        while len(terminal_states) < self.search_until_n_complete_plans and fringe:
            _state_cost, _state = fringe.pop(0)
            if len(_state) == 1:
                terminal_states.append((_state_cost, _state))
                continue

            possible_plans = self._get_possible_plans(
                query_node,
                _state,
                join_graph,
                bushy=bushy,
                planner_config=planner_config,
                avoid_eq_filters=avoid_eq_filters)
            print(len(possible_plans))
            costs = self.infer([join for join, _, _ in possible_plans])
            valid_costs, valid_new_states = self._make_new_states(
                _state, costs, possible_plans)

            # print(valid_new_states)

            for i, (valid_cost,
                    new_state) in enumerate(zip(valid_costs, valid_new_states)):
                fringe.append((valid_cost, new_state))

            fringe = sorted(fringe, key=lambda x: x[0])
            fringe = fringe[:beam_size]
            # print(fringe)

        # min_cost = np.min([c for c, s in terminal_states])
        planning_time = (time.time() - planning_start_t) * 1e3
        print('Planning took {:.1f}ms'.format(planning_time))
        print(terminal_states)
        min_cost_idx = np.argmin([c for c, s in terminal_states])

        return terminal_states[min_cost_idx][1][0]

    def _plan_priority_search(self,
                              query_node):
        init_state = query_node.GetLeaves()
        filters = query_node.GetFilters()
        # table = query_node.get_table_id()
        print(init_state)
        plan = self._model_based_plan_search(query_node, init_state)
        # plan = self._map_matching(plan)
        return plan

    def _cache_set_priority_search(self,
                                   query_node):
        init_state = query_node.GetLeaves()
        state = self._search_cache_set(init_state)
        plan = self._model_based_plan_search(query_node, state)
        return plan
