import torch
import torch.nn as nn

from models.attention import AttentionLayer, InfFlowAttention, ResConflictProbAttention
from models.encoder import Encoder, EncoderLayer, ConvLayer


class MutiQueryFormer(nn.Module):
    def __init__(self, c_out=1, factor=5, d_model=47, n_heads=8, e_layers=3, d_ff=512,
                 dropout=0.0, activation='gelu', attn='prob',
                 output_attention=False, distil=False):
        super(MutiQueryFormer, self).__init__()

        self.attn = attn
        self.output_attention = output_attention

        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        InfFlowAttention(False, factor, attention_dropout=dropout,
                                         output_attention=output_attention),
                        ResConflictProbAttention(False, factor, attention_dropout=dropout,
                                                 output_attention=output_attention),
                        d_model, n_heads, mix=False),
                    d_model,
                    d_ff,
                    dropout=dropout,
                    activation=activation
                ) for l in range(e_layers)
            ],
            [
                ConvLayer(
                    d_model
                ) for l in range(e_layers - 1)
            ] if distil else None,
            norm_layer=torch.nn.LayerNorm(d_model)
        )
        self.projection = nn.Linear(d_model, c_out, bias=True)

    def forward(self, x_enc, query_len, inf_flow_mask=None, res_conflict_mask=None):
        enc_out = self.enc_embedding(x_enc)
        enc_out, inf_attn, res_attn = self.encoder(enc_out, inf_flow_mask=inf_flow_mask,
                                                   res_conflict_mask=res_conflict_mask)
        enc_out = self.average(enc_out, query_len)
        enc_out = self.projection(enc_out)
        if self.output_attention:
            return enc_out, inf_attn, res_attn
        else:
            return enc_out  # [B, L, D]

    def average(self, enc_out, query_len):
        result = torch.stack([self.average_one(enc_out[i], query_len[i]) for i in range(len(query_len))], dim=0)
        return result

    def average_one(self, enc_out, query_len):
        output = torch.split(enc_out, query_len, dim=0)
        result = torch.stack([torch.mean(chunk, dim=0) for chunk in output], dim=0)
        return result

    def enc_embedding(self, x_enc):
        features, heights, positions = x_enc.features, x_enc.heights, x_enc.positions
        heights = heights.unsqueeze(-1).unsqueeze(0)
        positions = positions.unsqueeze(-1).unsqueeze(0)
        enc_out = torch.cat((features, positions, heights), dim=2)
        return enc_out
